package com.gamebooster.app

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private data class P(val name: String, val res: Int, val gm: String, val ram: Boolean, val dnd: Boolean, val anim: Boolean)

    private val profiles = listOf(
        P("Rendimiento", 60, "performance", true, true, true),
        P("Equilibrado", 80, "standard", false, false, true),
        P("Calidad", 100, "standard", false, false, false)
    )
    private val pkgs = mutableListOf<String>()
    private var gm = "standard"
    private lateinit var status: TextView
    private lateinit var out: TextView
    private lateinit var spinner: Spinner
    private lateinit var seek: SeekBar
    private lateinit var seekLabel: TextView
    private lateinit var ram: CheckBox
    private lateinit var dnd: CheckBox
    private lateinit var anim: CheckBox
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Shizuku.addRequestPermissionResultListener(permListener)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun tv(t: String, size: Float = 16f) = TextView(this).apply { text = t; textSize = size; setPadding(0, 24, 0, 8) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        root.addView(tv("Game Booster", 28f))
        status = tv(""); root.addView(status)
        root.addView(btn("Conectar Shizuku") { connect() })

        root.addView(tv("Juego"))
        spinner = Spinner(this)
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        pkgs.addAll(apps.map { it.first })
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, apps.map { it.second })
        root.addView(spinner)

        root.addView(tv("Perfil"))
        seek = SeekBar(this).apply { max = 50 }
        seekLabel = tv("")
        ram = CheckBox(this).apply { text = "Cerrar apps en segundo plano" }
        dnd = CheckBox(this).apply { text = "No molestar" }
        anim = CheckBox(this).apply { text = "Animaciones reducidas" }
        val rg = RadioGroup(this)
        profiles.forEachIndexed { i, p -> rg.addView(RadioButton(this).apply { text = p.name; id = i + 1 }) }
        rg.setOnCheckedChangeListener { _, id ->
            val p = profiles[id - 1]
            seek.progress = p.res - 50
            ram.isChecked = p.ram; dnd.isChecked = p.dnd; anim.isChecked = p.anim; gm = p.gm
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { seekLabel.text = "Resolución: ${p + 50}%" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(rg)
        root.addView(seekLabel); root.addView(seek)
        root.addView(ram); root.addView(dnd); root.addView(anim)
        rg.check(2)

        root.addView(btn("Aplicar y jugar") { apply() })
        root.addView(btn("Restaurar todo") { restore() })
        out = tv("", 13f); root.addView(out)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onDestroy() { Shizuku.removeRequestPermissionResultListener(permListener); super.onDestroy() }

    private fun ok() = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
    private fun refresh() { status.text = if (ok()) "Shizuku: conectado ✔" else "Shizuku: sin conexión ✖" }
    private fun log(s: String) = runOnUiThread { out.append(s + "\n") }

    private fun connect() {
        try {
            if (!Shizuku.pingBinder()) Toast.makeText(this, "Abre Shizuku e inícialo primero", Toast.LENGTH_LONG).show()
            else if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(1)
        } catch (e: Throwable) { Toast.makeText(this, "Shizuku no disponible", Toast.LENGTH_LONG).show() }
        refresh()
    }

    private fun sh(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val o = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return o.trim()
    }
    private fun r(cmd: String) { val o = sh(cmd); if (o.isNotEmpty()) log(o) }

    private fun work(f: () -> Unit) {
        if (!ok()) { connect(); return }
        Thread { try { f() } catch (e: Exception) { log("Error: ${e.message}") } }.start()
    }

    private fun apply() {
        val pkg = pkgs.getOrNull(spinner.selectedItemPosition) ?: return
        val pct = seek.progress + 50
        val doRam = ram.isChecked; val doDnd = dnd.isChecked; val a = if (anim.isChecked) "0.5" else "1"; val g = gm
        work {
            val sz = sh("wm size").lines().firstOrNull { it.startsWith("Physical size") }?.substringAfter(": ")?.trim()?.split("x")
            val dn = sh("wm density").lines().firstOrNull { it.startsWith("Physical density") }?.substringAfter(": ")?.trim()?.toIntOrNull()
            if (pct >= 100) r("wm size reset; wm density reset")
            else if (sz != null && sz.size == 2 && dn != null) {
                val w = sz[0].toInt() * pct / 200 * 2
                val h = sz[1].toInt() * pct / 200 * 2
                r("wm size ${w}x$h; wm density ${dn * pct / 100}")
            }
            r("cmd game set --mode $g $pkg")
            r("settings put global window_animation_scale $a; settings put global transition_animation_scale $a; settings put global animator_duration_scale $a")
            if (doDnd) r("cmd notification set_dnd priority")
            if (doRam) {
                val l = sh("pm list packages -3").lines().map { it.removePrefix("package:").trim() }
                    .filter { it.contains('.') && it != pkg && it != packageName }
                l.forEach { sh("am force-stop $it") }
                log("Apps cerradas: ${l.size}")
            }
            log("Aplicado: $pct%, modo $g")
            Thread.sleep(800)
            runOnUiThread { packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } }
        }
    }

    private fun restore() = work {
        r("wm size reset; wm density reset; settings put global window_animation_scale 1; settings put global transition_animation_scale 1; settings put global animator_duration_scale 1; cmd notification set_dnd off")
        log("Restaurado")
    }
}
